<?php
$host = 'localhost';
$user = 's11820346_oop';
$pass = 'ch3rry_Puzzl3';
$db = 's11820346_oop';

$mysqli = new mysqli($host, $user, $pass, $db);

// Check connection
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// Optional: Set charset to UTF-8
$mysqli->set_charset("utf8mb4");
?>
