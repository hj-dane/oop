<?php
// Use your SMTP provider (e.g., SendGrid/Mailgun/Gmail SMTP App Password).
// Keep this file OUTSIDE web root in production.
const SMTP_HOST       = 'smtp.gmail.com';
const SMTP_PORT       = 587;
const SMTP_SECURE     = 'tls'; // or 'ssl'
const SMTP_USERNAME   = '24100740@usc.edu.ph';
const SMTP_PASSWORD   = 'nayjtnekccgjpenz';
const SMTP_FROM_EMAIL = '24100740@usc.edu.ph';
const SMTP_FROM_NAME  = 'Insync';
